#!/bin/bash

java test
java test
java test
java test
java test
java test
java test
java test
java test
java test
