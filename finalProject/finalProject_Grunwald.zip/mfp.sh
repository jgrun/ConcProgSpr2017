#!/bin/bash

javac circBuf.java
javac noLock.java
javac coarseReentrant.java
javac fineReentrant.java
javac lfsr.java
javac atomicBuf.java
javac test.java
javac test1.java
javac test2.java
